export { footerConfig } from "./footerConfigs";
